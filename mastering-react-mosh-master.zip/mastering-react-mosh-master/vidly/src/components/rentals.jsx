import React from "react";

const Rentals = () => {
  return <h1>Rentals</h1>;
};

export default Rentals;
