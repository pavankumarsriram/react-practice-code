import React from "react";

const Users = () => {
  return <h1>Admin Users</h1>;
};

export default Users;
